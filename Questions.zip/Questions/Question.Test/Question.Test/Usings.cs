global using Xunit;
global using Microsoft.Extensions.DependencyInjection;